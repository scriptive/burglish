function wD(Oy, gM) {
  gM = gM ? gM : hz;
  return hT(Oa[gM].OE[Oy]);
};