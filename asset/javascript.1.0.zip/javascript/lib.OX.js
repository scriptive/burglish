function OX(Oz) {
  // var Kl = $(Oz).offsetLeft;
  // var w7 = $(Oz).offsetTop;
  // while (i = OT.offsetParent) {
  //   Kl += i.offsetLeft;
  // }
  // while (i = OT.offsetParent) {
  //   w7 += i.offsetTop;
  // }
  return [$(Oz).offsetLeft, $(Oz).offsetTop];
}