var gM = {};
// =require int.NO.js
// =require int.gf.js
gJ.int = true;