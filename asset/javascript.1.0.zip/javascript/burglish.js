(function(os,win,doc) {
  'use strict';
  // lib,burglish,burmese,syllable
  // =require basic.Default.js
  // =require lib.Default.js
  // =require int.Default.js
  // =require burglish.Default.js
  // =require burmese.Default.js
  // =require syllable.Default.js
  // =require english.Default.js
  // =require language.Default.js
  var eSrc='source',
  eTar='target',
  eOpt='Options',
  eSwp='Switch',
  eFoc='Force',
  eExc='Except',
  eTxt='Text',
  app={
    id:{
      source:'source',
      target:'target',
      input:'sourceOptions',
      swap:'sourceSwitch',
      output:'targetOptions',
      text:'Text',
      force:'force',
      exception:'exceptions'
    },
    taskSwap:{
      switchFont:{
        title:'switch Input and Output fonts',
        class:'icon-switch-fonts',
        handler:function(){
          var t = gM.target.name, s = gM.source.name;
          NO('source',t); NO('target',s);
        }
      }
    },
    taskOption:{
      showFilter:{
        title:'show filter',
        class:'option icon-show-filter',
        handler:function(e){
          gJ.basic=e.classList.contains("active");
          e.classList.toggle("active");
          if (gJ.basic){
            $("wL").classList.remove('active');
              // $("wR").style.display = "none";
            $("wR").style.display = "none";
          } else {
            $("wL").classList.add('active');
            // $("wR").style.display = "block";
            // $("wR").style.display = "block";
            $("wR").removeAttribute("style");
            // $("wL").removeAttribute("style");
            gb();
          }
        }
      },
      charCode:{
        class:'icon-convert-code',
        title:'character Code',
        handler:function(){
          g9();
        }
      },
      escapeUnicode:{
        class:'icon-convert-escape',
        title:'escape Unicode',
        handler:function(){
          N3();
        }
      },
      convertWithFilter:{
        class:'icon-convert-filter',
        title:'Convert using filter',
        id:'wR',
        style:'display:none;',
        handler:function(){Nl(true, "g1");}
      },
      Convert:{
        text:'Convert',
        class:'icon-convert-normal',
        // class:'icon-emo-happy',
        handler:function(){
          Qx();
        }
      }
    },
    intTask: function() {
      var task = app.taskOption,
      container = $(app.id.output),
      promises = Object.keys(task).map(function(n, i) {
        var li = eCreate("li"), o = task[n];
        if (o.hasOwnProperty('text')){
          li.appendChild(doc.createTextNode(o.text));
        }
        if (o.hasOwnProperty('class')){
          li.setAttribute('class', o.class);
        }
        if (o.hasOwnProperty('id')){
          li.setAttribute('id', o.id);
        }
        if (o.hasOwnProperty('style')){
          li.setAttribute('style', o.style);
        }
        if (o.hasOwnProperty('title')){
          li.setAttribute('data-title', o.title);
        }
        li.addEventListener("click", function(event){
          if (o.hasOwnProperty('handler')) o.handler(event.target);
        });
        container.appendChild(li);
      });
      Promise.all(promises).then(function(){
        var task = app.taskSwap,
        container = $(app.id.swap),
        promises = Object.keys(task).map(function(n, i) {
          var li = eCreate("li"), o = task[n];
          if (o.hasOwnProperty('text')){
            li.appendChild(doc.createTextNode(o.text));
          }
          if (o.hasOwnProperty('class')){
            li.setAttribute('class', o.class);
          }
          if (o.hasOwnProperty('id')){
            li.setAttribute('id', o.id);
          }
          if (o.hasOwnProperty('style')){
            li.setAttribute('style', o.style);
          }
          if (o.hasOwnProperty('title')){
            li.setAttribute('data-title', o.title);
          }
          li.addEventListener("click", function(event){
            if (o.hasOwnProperty('handler')) o.handler(event.target);
          });
          container.appendChild(li);
        });
      }).then(function(){
        NO(eSrc, "Zawgyi");
        NO(eTar, "WinInnwa");
        $(app.id.exception).value = g8;
        $(app.id.force).value = QN;
      }).then(function(){
        gZ({id: eText(eSrc),N_: true,self: true,KY:false,rows: 20});
      });
    },
    int:function(a){
      gM[eSrc]={name:'Zawgyi'};
      gM[eTar]={name:'Myanmar3',direct:true};
      app.request.text=a;
      return app.request;
    },
    request:{
      load:function(b,c){
        app.intTask();
      },
      convert:function(b,c){
        return this.text.Ng(b,c);
      }
    }
  };
  win[os]=app.int;
}("Burglish",window,document));