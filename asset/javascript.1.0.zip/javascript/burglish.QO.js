function QO(KV, wG) {
  var hU = OD[OD.x]["Ke"] = wG;
  if (wC(hU.substr(hU.length - 1, 1)) == 82) {
    OD[OD.x]["plChar"] = hU.substr(hU.length - 2, 1);
  }
  OD[OD.x]["w5"] = KV;
  OD[OD.x]["KV"] = "";
  OD[OD.x]["Km"] = 0;
  OD[OD.x]["hC"] = -1;
  Kx(OD.x + "drop");
};