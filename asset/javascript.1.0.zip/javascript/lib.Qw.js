function Qw(evt) {
  if (gR) {
    g4.style.left = QW ? tx + evt.clientX - N5 : tx + event.clientX - N5;
    g4.style.top = QW ? ty + evt.clientY - Nr : ty + event.clientY - Nr;
    return false;
  }
};