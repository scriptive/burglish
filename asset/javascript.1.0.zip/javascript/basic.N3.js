function N3() {
  $(eText(eTar)).value = NJ(Qu($(eText(eSrc)).value));
};