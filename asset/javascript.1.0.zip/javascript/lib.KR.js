function KR(hi, Or, OJ, QM, QK) {
  w1 ? QC(hi, Or, OJ, QM, QK) : Q0(hi, Or, OJ, QM, QK);
};