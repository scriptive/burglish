function Ku(e) {
  try {
    var Ot = eval(e);
    if (typeof(eval(e)) != "undefined") return true;
  } catch (e) {}
  return false;
}