function ND() {
  var OT = $(OD.x);
  if (OD[OD.x]['KY']) {
    KR(OT, '[gM="' + Oa[hz].QJ + '"]', '[/gM]');
  }
  return false;
};