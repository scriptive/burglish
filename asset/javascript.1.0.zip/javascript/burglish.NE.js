function NE(wx) {
  if (wx) {
    OD.x = wx.id;
    wx.focus();
  }
};