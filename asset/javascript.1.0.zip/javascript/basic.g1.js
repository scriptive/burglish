function g1() {
  if ($(app.id.force).value != QN) QN = $(app.id.force).value;
  if ($(app.id.exception).value != g8) g8 = $(app.id.exception).value;
  var wq = $(eText(eSrc)).value;
  self.status = gM[eSrc].name + " ->" + gM[eTar].name;
  var Ot = wq;
  if (!Oa[gM[eSrc].name].unicode) {
    Ot = Ot.Q5();
  }
  Ot = Ot.Ng(gM[eSrc].name, gM[eTar].name);
  if (!Oa[gM[eSrc].name].unicode) {
    Ot = Ot.Nf();
  }
  $(eText(eTar)).value = Ot;
  Nl(false);
};