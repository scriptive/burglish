function gA() {
  $(eText(eTar)).value = unescape($(eText(eSrc)).value);
};