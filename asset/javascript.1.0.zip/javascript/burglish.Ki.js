function Ki(wx) {
  if ($(wx.id + "drop")) Kx(wx.id + "drop");
  return false;
};