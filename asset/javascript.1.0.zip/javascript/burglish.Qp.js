function Qp() {
  var wx = $(OD.x);
  wx.focus();
  gt(wx);
};