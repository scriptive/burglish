function wC(Oz, gM) {
  gM = gM ? gM : hz;
  var hN = Oa[gM].OE;
  for (var i = 0; i < hN.length; i++) {
    if (hT(hN[i]) == Oz) {
      return i;
    }
  }
};