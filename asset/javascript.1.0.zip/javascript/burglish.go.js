function go(OT) {
  // if (!OT.tag) return;
  // $(OT.tag).innerHTML = '<textarea style="height:' + (OT.rows ? OT.rows * 30 : 30) + ';" rows="' + (OT.rows ? OT.rows : 1) + '" id="' + OT.id + '"' + ' autocomplete="off" ' + 'onkeydown="return Ns(event);"' + (w1 ? 'onkeypress="NL(event);"' : '') + 'onkeyup="QF(event);"' + 'onmouseup="QF(event);"' + 'onblur="Ki(this);"' + 'onfocus="onFocus(this);">' + '</textarea>';
  // doc.body.innerHTML += '<span id="' + OT.id + 'drop"' + ' class="g7">' + '</span>';
};