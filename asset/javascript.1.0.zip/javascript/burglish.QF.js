function QF(e) {
  var wx = e.target ? e.target : e.srcElement;
  gt(wx);
};