function Os(Oz) {
  var OT = $(OD.x);
  KR(OT, Oz);
  OT.focus();
};